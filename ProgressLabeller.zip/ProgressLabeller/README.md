# Progress Labeller

## Overview

**This is an developing repository**. The project is an blender add-on to re-implement a pipeline, Labelfusion. Labelfusion is a pipleine to generate ground truth object-centric pose and mask labels from sequential images. It is powerful, but we find it is hard to install due to some out-of-date dependencies. Therefore, this project is trying to re-implement Labelfusion in a more user-friendly, cross-platform software, blender. Moreover, we would further improve the accuracy of Labelfusion, and make it model-free.

## Table of contents
-----
  * [Installation](#installation)
  * [Data structure](#data-structure)
  * [Quick Start](#what-we-have-achieved)
  * [Reference](#reference)
------

## Installation

### Install add-on in blender

### Install denpencies

## Data structure

## What we have achieved

## Reference
